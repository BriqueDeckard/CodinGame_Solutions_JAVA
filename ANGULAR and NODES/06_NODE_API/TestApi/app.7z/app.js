/**
 * Salut Iscia. 
 * 
 * 1. PREPARATION
 * 1.1. MongoDB:
 * 
 * Déjà, il faut avoir MongoDb d'installé;
 * --> https://www.mongodb.com/try/download/community
 * 
 * Là, il te faut une base de données.
 * Tu ouvre l'invité de commande :
 * 
       Windows + R ;
 * 
 * Dedans, tu et tape "cmd" pour ouvrir une console.
 * 
 * Depuis cette console, tu vas dans le dossier d'installation de MongoDb.
 * Ca doit etre quelque chose du genre :
 *    
      E:\Program Files\MongoDB\Server\5.0\bin
 * 
 * Pour changer de dossier, tu tape : 
 * 
       cd chemin\du\dossier
 * 
 * par exemple: 
 * 
       cd E:\Program Files\MongoDB\Server\5.0\bin
 * 
 * Une fois que tu es dans ce dossier depuis la console, tu tape "mongo.exe"
 * Normalement, ça va t'afficher du texte, puis ton "pointeur" (où tu tape)
 * va devenir ">"
 * 
 * Là, tu peux taper "db" pour lister les bases qui existent.
 * 
 * On va créer une base. Tu tape (toujours dans la console après le ">") :
 * 
      use things
 * 
 * Ca devrait t'afficher 'switched to db things'
 * 
 * Pour insérer des données, ça se fait comme ça :
 * 
 *     
        db.peoples.insert({
                           identifiant:1,
                            nom:"Bob",
                            age:45
                         })
                         
 * Là on a inséré une seule entrée :
 *                         
    db       -> Dans la base en cours, la base 'things'
    .peoples -> Dans la collection 'peoples'
    
    avec l'identifiant '1', le nom 'bob' et l'age '45'.
 * 
 * 
 * On ecrit les données a insérer en langage "JSON" :
 *    {
 *      propriété1:valeur,
 *      propriété2:valeur
 *     }
 *  
 * 
 * Si tout s'est bien passé, ça devrait t'afficher : 
 
        WriteResult({ "nInserted" : 1 })
  
 * 
 * 
 * 1.2. L'api:
 *  * que tu viens de créer: "monApi"
 * Crée un dossier "monApi" quelque part, et colle ce fichier dedans.
 * 

 * 
 * (tu peux voir ce que contient le dossier en tapant:  dir 
 *  et tu peux 'remonter' dans les dossier en tapant: ../ )
 * 
 * Quand tu es dans le dossier, tu tape:
 * 
 *      npm init -y
 *  
 * Cette commande va initialiser le projet Node, et créer un fichier
 * "package.json"
 * 
 * Toujours dans la console, tu tape:
 * 
 *      npm install express
 * 
 * ça va installer express.
 * 
 * Toujours dans la console, enfin, tu tape : 
 * 
 *      npm install mongodb
 * 
 * Pour installer mongodb POUR LE PROJET
 * 
 * Dans le fichier "package.json", tu vérifie qu'il y a bien un truc dans ce genre là :
 * 
 *  "dependencies": {
 *    "express": "^4.17.1"
 *  }
 * 
 * Ensuite, voila le code 'expliqué'. 
 * Pour le lancer, tu vas dans la console, et tu tape 
 * 
 * node app.js
 * 
 */

// #### Connection à MongoDb et 'population' de la base

// On récupère MongoDb
const mongoClient = require('mongodb').MongoClient;

// On ecrit l'url de mongodb
const url = 'mongodb://localhost:27017';
// On ecrit le nom de la base
const dbName = 'things';

// On se connecte à Mongo
mongoClient.connect(url, (error, client)=> {
    
    // On gère les potentielles erreurs de connexion
    if(error) {
        console.log("Erreur connection");
        throw error;
    }
    // Sinon on confirme que ça marche
    else{
        console.log("Connecté à MongoDb");
    }
    
    // on récupère la base
    const db = client.db(dbName);   

    // On récupère la collection
    const collection =  db.collection('peoples');

    // POUR INSERER DES DONNES
    // a. Creation de l'objet
    const objectTonInsert = {
        identifiant:3,
        nom:"Sam",
        age:37
     }
     // b. Insertion dans la base
    collection.insertOne(objectTonInsert, (err, res)=>{
        if(err) throw err;
        console.log("1 document inséré")
    })

    // POUR RECUPERER DES DONNEES
    // a. Tout récupérer
    const peoples = collection.find({});

    peoples.forEach(element => {
        console.log("Element :" + element.identifiant + ", nom : ", element.nom);
    });

    // b. Récupérer selon une requete --> tous les objets dont le nom est 'sam'
    var query = { nom: "Sam"};

    const Sam = collection.find(query).toArray((err, res)=> {
        if(err) throw err;
        console.log(res);
    })

    
});



 // #### Creation de l'instance d'une application express
 
// On récupère le framework express
const express = require('express');

// On instancie express --> On crée un "objet" express
const app = express();
// On définit le port.  C'est grâce à ça que l'api communique avec le reste du monde.
const port = 3000;

// app.get() te permet de 'router', c'est à dire de définir comment 
// ton application va répondre quand on ira sur l'adresse '3000/'
//
// Entre les parenthèses, le premier truc, c'est la 'route', le chemin.
// le '/' c'est pour dire qu'on est à la racine de l'adresse. 
// Si tu veux d'autres adresse, tu rajoute des mots là. (:
// Exemple : Si tu voulais que ton appli reagisse à l'adresse '3000/kiwi/',
// tu mettrait 'app.get('/kiwi/', ...)
//
// Le second truc entre les parenthèses, c'est le 'handler', la méthode executée 
// quand la 'route' est trouvée et que tout est ok.
// 
// La, le '(request, response) =>  ...' c'est une 'lambda'. C'est une manière raccourcie
// d'écrire une 'méthode', mais je vais pas rentrer dans les détails.
// Ca évite d'avoir à écrire : 
//
//      app.get('/', function (request, response) {
//          res.send('Hello World!');
//      });
//
// 'request' c'est un objet qui contient des infos sur la REQUETE http qui a déclenché la méthode
// 'response' c'est l'objet qui va contenir la réonse
// Ici on dit à l'objet 'response' de renvoyer 'hello world'.

// #### ROUTAGE
app.get('/', (request, response) => response.send('Hello world'));
app.get('/kiwi', (request, response) => response.send('Un peu decevant cette page.'));

// Mais on peut lui passer d'autres trucs, comme des objets.
// Pour ça, il faut 'serialiser' --> transformer en objet que le web peut transporter.
// C'est pour ça qu'on utilise le format 'JSON'. Ca tombe bien, c'est le format de MongoDB

// Ca tu peux le stocker dans une variable : 
const peopleToSend =  [
       {
           identifiant:1,
           nom:"Bob",
           age:45
        },
       {
           identifiant:2,
           nom:"Noah",
           age:27
        }
];

// Pour envoyer des objets il te suffit ensuite de les passer dans ta réponse :
app.get('/peoples', (request, response) => response.json(peopleToSend));

// Pour envoyer des objets que tu récupéré depuis mongo, c'est pas plus compliqué :

// Pour se simplifier la vie on va utiliser le "routeur" d'express :
const router = express.Router();

// Ensuite on va créer l'operateur Get :
router.get('/peoples', (req, res)=> res.send({type:'GET'}));



const messageToIscia = `Ton application "ecoute" sur le port ${port},\n
Tu peux aller sur http://localhost:3000/, il devrait t'afficher 'hello world'.\n
Si tu vas sur http://localhost:3000/kiwi/ il devrait t'afficher autre chose. \n
Si tu vas sur http://localhost:3000/peoples/ tu devrais voir deux "objets"`



// Demarrage de l'application web
app.listen(port, () => console.log(messageToIscia));